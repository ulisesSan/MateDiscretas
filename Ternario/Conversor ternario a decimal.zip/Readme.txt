Debe de instalar tkinter para poder ejecutar el script
